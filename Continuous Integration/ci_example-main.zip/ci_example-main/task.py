####################
#  - Function 1 -  #
####################
def conv_num(num_str: str) -> int | float | None:  # noqa: C901
    """
    Converts a string to a base 10 number (int or float).
    Does not take objects.
    """
    if not isinstance(num_str, str):
        return None

    if not num_str:  # Empty String
        return None

    num_str = num_str.strip()
    is_negative = num_str.startswith('-')
    if is_negative:
        num_str = num_str[1:]  # Remove the negative sign for processing

    if not num_str:  # Case where only '-' is passed
        return None

    # Hexadecimal case
    if num_str.lower().startswith('0x'):
        hex_part = num_str[2:]

        if not hex_part:  # Handle 0x case
            return None

        if '.' in hex_part:  # Hexadecimal cannot be a floating-point
            return None

        result = 0
        for char in hex_part.lower():
            if '0' <= char <= '9':
                value = ord(char) - ord('0')
            elif 'a' <= char <= 'f':
                value = ord(char) - ord('a') + 10
            else:
                return None  # Invalid character
            result = result * 16 + value
        return -result if is_negative else result

    # Floating-point case
    if '.' in num_str:
        parts = num_str.split('.')
        if len(parts) != 2 or not parts[0] and not parts[1]:  # Invalid format
            return None
        int_part = 0
        frac_part = 0.0
        if parts[0]:
            for char in parts[0]:
                if '0' <= char <= '9':
                    int_part = int_part * 10 + (ord(char) - ord('0'))
                else:
                    return None
            if is_negative:
                int_part = -int_part

        if parts[1]:
            divisor = 10
            for char in parts[1]:
                if '0' <= char <= '9':
                    frac_part += (ord(char) - ord('0')) / divisor
                    divisor *= 10
                else:
                    return None

        return int_part + (-frac_part if is_negative else frac_part)

    # Integer case

    result = 0
    for char in num_str:
        if '0' <= char <= '9':
            result = result * 10 + (ord(char) - ord('0'))
        else:
            return None
    return -result if is_negative else result


####################
#  - Function 2 -  #
####################
def my_datetime(num_sec):
    day_sec = 86400
    start_year = 1970

    day_total = num_sec // day_sec

    low = start_year
    high = low + day_total // 365 + 2

    while low <= high:
        mid = (low + high) // 2
        day_to_mid = days_after_start_year(mid)
        if day_to_mid <= day_total:
            low = mid + 1
        else:
            high = mid - 1

    year = high
    day_left = day_total - days_after_start_year(year)

    all_month_length = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

    if leap_check(year):
        all_month_length[1] = 29
    month = 1
    while day_left >= all_month_length[month - 1]:
        day_left -= all_month_length[month - 1]
        month += 1

    day = day_left + 1

    date_str = f"{month:02d}-{day:02d}-{year}"

    return date_str


def leap_after_start_year(year):
    leap_count = ((year - 1) // 4) - ((year - 1) // 100) + ((year - 1) // 400)
    leap_to_1969 = (1969 // 4) - (1969 // 100) + (1969 // 400)
    leap_total = leap_count - leap_to_1969
    return leap_total


def leap_check(year):
    if year % 4 != 0:
        return False
    elif year % 100 != 0:
        return True
    elif year % 400 != 0:
        return False
    else:
        return True


def days_after_start_year(year):
    day = (year - 1970) * 365 + leap_after_start_year(year)
    return day


####################
#  - Function 3 -  #
####################
def conv_endian(num, endian='big'):
    """
    Takes in an int and converts it to a hex number. Splits hex number into
    1 byte chunks. Returns hex number as a string
    """

    # Input validation
    if not isinstance(num, int):
        raise ValueError("The number must be an integer.")
    if endian not in ['big', 'little']:
        return None

    # Handle negative int (always do conversion on positive)
    is_negative = num < 0
    dec_num = abs(num)

    # Hex conversion array and hex number instantiation
    hex_arr = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B',
               'C', 'D', 'E', 'F']
    hex_num = []

    # Decimal to Hex conversion loop (This works)
    while dec_num > 0:
        remainder = dec_num % 16
        hex_num.append(hex_arr[remainder])
        dec_num //= 16

    # Case when num is 0
    if not hex_num:
        hex_num = ['0']

    # Convert arr to str and reverse to match big endian by default
    hex_string = ''.join(reversed(hex_num))

    # Add 0 to the front if it is an uneven amount of chars
    if len(hex_string) % 2 != 0:
        hex_string = '0' + hex_string

    # Convert str back into 2 char byte array for further processing
    formated_hex = []
    for i in range(0, len(hex_string), 2):
        two_byte_chunk = hex_string[i:i + 2]
        formated_hex.append(two_byte_chunk)

    # If little endian is selected, reverse byte chunks in array
    if endian == 'little':
        formated_hex.reverse()

    # Convert array back into string
    final_result = ' '.join(formated_hex)

    # Check for negative and add negative sign back
    if is_negative:
        final_result = '-' + final_result

    return final_result
