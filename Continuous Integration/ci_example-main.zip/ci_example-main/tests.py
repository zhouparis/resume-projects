import unittest
from task import conv_endian
from task import conv_num
from task import my_datetime


class TestCase(unittest.TestCase):

    ###############################
    #  - Function 1 Test Suite -  #
    ###############################
    # Canvas sample tests
    def test1_1(self):
        self.assertEqual(conv_num('12345'), 12345)

    def test1_2(self):
        self.assertEqual(conv_num('-123.45'), -123.45)

    def test1_3(self):
        self.assertEqual(conv_num('.45'), 0.45)

    def test1_4(self):
        self.assertEqual(conv_num('123.'), 123.0)

    def test1_5(self):
        self.assertEqual(conv_num('0xAD4'), 2772)

    def test1_6(self):
        self.assertEqual(conv_num('0xad4'), 2772)

    def test1_7(self):
        self.assertEqual(conv_num('0xAZ4'), None)

    def test1_8(self):
        self.assertEqual(conv_num('12345A'), None)

    def test1_9(self):
        self.assertEqual(conv_num('12.3.45'), None)

    # Manual tests for Function 1
    def test_valid_integers(self):
        self.assertEqual(conv_num("123"), 123)
        self.assertEqual(conv_num("-123"), -123)
        self.assertEqual(conv_num("0"), 0)

    def test_valid_floats(self):
        self.assertAlmostEqual(conv_num("123.456"), 123.456)
        self.assertAlmostEqual(conv_num("-123.456"), -123.456)
        self.assertAlmostEqual(conv_num("0.0"), 0.0)
        self.assertAlmostEqual(conv_num("10.0"), 10.0)
        self.assertAlmostEqual(conv_num("0.123"), 0.123)
        self.assertAlmostEqual(conv_num("-0.123"), -0.123)

    def test_valid_hexadecimal(self):
        self.assertEqual(conv_num("0x1A3F"), 0x1A3F)
        self.assertEqual(conv_num("0x0"), 0)
        self.assertEqual(conv_num("-0xFF"), -0xFF)

    def test_invalid_hexadecimal(self):
        self.assertIsNone(conv_num("0x123.456"))
        self.assertIsNone(conv_num("0xZZZ"))
        self.assertIsNone(conv_num("0x12G"))
        self.assertIsNone(conv_num("0x"))

    def test_invalid_formats(self):
        self.assertIsNone(conv_num("123..456"))
        self.assertIsNone(conv_num("abc"))
        self.assertIsNone(conv_num("123abc"))
        self.assertIsNone(conv_num("-"))
        self.assertIsNone(conv_num(".."))
        self.assertIsNone(conv_num("."))

    def test_edge_cases(self):
        self.assertIsNone(conv_num(""))
        self.assertIsNone(conv_num(" "))
        self.assertIsNone(conv_num("\t"))
        self.assertIsNone(conv_num("\n"))
        self.assertEqual(conv_num("0000123"), 123)
        self.assertAlmostEqual(conv_num("0000123.04500"), 123.045)

    def test_non_string_inputs(self):
        self.assertIsNone(conv_num(None))
        self.assertIsNone(conv_num(123))  # Integer input
        self.assertIsNone(conv_num(123.456))  # Float input
        self.assertIsNone(conv_num([]))  # List input
        self.assertIsNone(conv_num({}))  # Dictionary input
        self.assertIsNone(conv_num(True))  # Boolean input

    ###############################
    #  - Function 2 Test Suite -  #
    ###############################
    def test2_1(self):
        self.assertEqual(my_datetime(0), '01-01-1970')

    def test2_2(self):
        self.assertEqual(my_datetime(123456789), '11-29-1973')

    def test2_3(self):
        self.assertEqual(my_datetime(9876543210), '12-22-2282')

    def test2_4(self):
        self.assertEqual(my_datetime(201653971200), '02-29-8360')

    ###############################
    #  - Function 3 Test Suite -  #
    ###############################
    # Canvas sample tests
    def test3_1(self):  # Not default big endian
        self.assertEqual(conv_endian(954786, 'big'), '0E 91 A2')

    def test3_2(self):  # Default big endian
        self.assertEqual(conv_endian(954786), '0E 91 A2')

    def test3_3(self):  # Default, negative big endian
        self.assertEqual(conv_endian(-954786), '-0E 91 A2')

    def test3_4(self):  # Little endian
        self.assertEqual(conv_endian(954786, 'little'), 'A2 91 0E')

    def test3_5(self):  # Negative little endian
        self.assertEqual(conv_endian(-954786, 'little'), '-A2 91 0E')

    def test3_6(self):  # Defined num, negative little endian
        self.assertEqual(conv_endian(num=-954786, endian='little'),
                         '-A2 91 0E')

    def test3_7(self):  # Defined num, negative invalid endian
        self.assertEqual(conv_endian(num=-954786, endian='small'), None)

    # Manual edge case tests
    def test3_8(self):  # Case when num is 0
        self.assertEqual(conv_endian(0, 'little'), '00')

    def test3_9(self):  # Case when num is -0
        self.assertEqual(conv_endian(-0, 'big'), '00')

    def test3_10(self):  # Big number, default big endian
        self.assertEqual(conv_endian(987654321), '3A DE 68 B1')

    def test3_11(self):  # Big number, little endian
        self.assertEqual(conv_endian(987654321, 'little'), 'B1 68 DE 3A')

    def test3_12(self):  # Really big number, default big
        self.assertEqual(conv_endian(15802469136), '03 AD E6 8B 10')

    def test3_13(self):  # Really big number, little
        self.assertEqual(conv_endian(15802469136, 'little'), '10 8B E6 AD 03')

    def test3_14(self):  # Big negative number, default big endian
        self.assertEqual(conv_endian(-987654321), '-3A DE 68 B1')

    def test3_15(self):  # Big negative number, little endian
        self.assertEqual(conv_endian(-987654321, 'little'), '-B1 68 DE 3A')

    def test3_16(self):  # Really big negative number, default big
        self.assertEqual(conv_endian(-15802469136), '-03 AD E6 8B 10')

    def test3_17(self):  # Really big negative number, little
        self.assertEqual(conv_endian(-15802469136, 'little'),
                         '-10 8B E6 AD 03')

    # Num can only be an int but testing that input for ValueError anyways
    def test3_18(self):
        with self.assertRaises(ValueError):
            conv_endian('string', 'little')


if __name__ == '__main__':
    unittest.main()
