#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8888
#define PAYLOAD_SIZE 200  // Overflow trigger size

int main() {
    int sock;
    struct sockaddr_in server_addr;
    char payload[PAYLOAD_SIZE + 1];  // Extra byte for null termination

    // Create a large payload of 'A' characters
    memset(payload, 'A', PAYLOAD_SIZE);
    payload[PAYLOAD_SIZE] = '\0';  // Ensure null termination

    // Create a socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // Define server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("connect failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    printf("Connected to server, sending fuzzing payload...\n");

    // Send the payload
    if (send(sock, payload, strlen(payload), 0) == -1) {
        perror("send failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    printf("Payload sent! Check if the server crashes.\n");

    // Close the socket
    close(sock);

    return 0;
}
