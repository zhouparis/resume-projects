/*
  All code was copied from CS340 Activity2 Prompt
/


/*
    SETUP
*/
// Express
var express = require('express');   // We are using the express library for the web server
var app     = express();            // We need to instantiate an express object to interact with the server in our code
PORT        = 9177;                 // Set a port number at the top so it's easy to change in the future
const path = require('path');

// Database
var db = require('./db-connector')

//set up handlebars
const { engine } = require('express-handlebars');
var exphbs = require('express-handlebars');     // Import express-handlebars
const  create_customers_table =  require( './public/js/tables/create_customer_table.js');
const create_orders_table  = require('./public/js/tables/create_orders_table.js');
const create_transactions_table = require('./public/js/tables/create_transactions.js');
const create_vehicles_table = require('./public/js/tables/create_vehicles.js');
const create_warranties_table = require('./public/js/tables/create_warranties.js');
const create_warrantyDetails_table = require('./public/js/tables/create_warranty_details.js');
app.engine('.hbs', engine({extname: ".hbs"}));  // Create an instance of the handlebars engine to process templates
app.set('view engine', '.hbs');                 // Tell express to use the handlebars engine whenever it encounters a *.hbs file.


//configure to use json
app.use(express.json())
app.use(express.urlencoded({extended: true}))
app.use(express.static('public'))

//temp setup table

const mysql_setup = require( './public/js/tables/table_settings.js');
const { parse } = require('querystring');



/*
    ROUTES
*/
app.get('/', function(req, res)
    {

        //Refresh Database
        mysql_setup(db)
        create_customers_table(db)
        create_orders_table(db)
        create_transactions_table(db)
        create_vehicles_table(db)
        create_warranties_table(db)
        create_warrantyDetails_table(db)


        res.render('index')
    });

app.get('/vehicles', function(req, res)
    {
        let get_vehicles_table_query = "SELECT * FROM Vehicles"

        db.pool.query(get_vehicles_table_query, function(error, rows, fields){
            res.render("vehicles", {data:rows});
        })
    });

app.post('/add-vehicle-ajax', function(req, res) {
    let data = req.body;

    // Insert validation here

    let add_vehicle_query = `INSERT INTO Vehicles (VIN, make, model, year, engine, allWheelDrive, \`4x4\`, electricDriveTrain, color) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    let values = [
        data.VIN,
        data.make,
        data.model,
        data.year,
        data.engine,
        data.allWheelDrive,
        data.fourByFour,
        data.electricDriveTrain,
        data.color
    ];

    db.pool.query(add_vehicle_query, values, function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            let get_vehicles_table_query = "SELECT * FROM Vehicles";
            db.pool.query(get_vehicles_table_query, function(error, rows, fields) {
                if (error) {
                    console.log(error);
                    res.sendStatus(400);
                } else {
                    res.send(rows);
                }
            });
        }
    });
});

app.delete('/delete-vehicle-ajax', function(req, res, next) {
    let data = req.body;
    let VIN = data.VIN;
    let delete_vehicle_query = 'DELETE FROM Vehicles WHERE VIN = ?';

    db.pool.query(delete_vehicle_query, [VIN], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            res.sendStatus(200);
        }
    });
});

app.put('/update-vehicle-ajax', function(req, res, next) {
    let data = req.body;

    let VIN = data.VIN;
    let make = data.make;
    let model = data.model;
    let year = data.year;
    let engine = data.engine;
    let allWheelDrive = data.allWheelDrive;
    let fourByFour = data.fourByFour;
    let electricDriveTrain = data.electricDriveTrain;
    let color = data.color;

    let query_update_vehicle = `UPDATE Vehicles SET make = ?, model = ?, year = ?, engine = ?, allWheelDrive = ?, \`4x4\` = ?, electricDriveTrain = ?, color = ? WHERE VIN = ?`;

    db.pool.query(query_update_vehicle, [make, model, year, engine, allWheelDrive, fourByFour, electricDriveTrain, color, VIN], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            console.log("Vehicle updated successfully");
            res.sendStatus(200);
        }
    });
});

    

app.get('/customers', function(req, res)
    {

        let  get_customers_table_query = "SELECT * FROM Customers" 

        db.pool.query(get_customers_table_query, function(error, rows, fields){
            res.render("customers", {data:rows});
        })

    });

app.post('/add-customer-ajax', function(req, res){

    let data = req.body;

    //insert validation here

    add_customer_query = `INSERT INTO Customers (name, email, phoneNumber, patron) VALUES ('${data.name}', '${data.email}', '${data.phoneNumber}','0')`;

    db.pool.query(add_customer_query, function(error, rows, fields){

        if (error){
            console.log(error)
            res.sendStatus(400)
        }

        else{
            get_customers_table_query = "SELECT * FROM Customers" 
            db.pool.query(get_customers_table_query, function(error, rows, fields){
                if(error){
                    console.log(error)
                    res.sendStatus(400)
                }
                else{
                    res.send(rows)
                }
            })
        }
    })
})

app.delete('/delete-customer-ajax', function(req, res, next){
    let data = req.body;
    let customerID = parseInt(data.id)
    let delete_customer = 'DELETE FROM Customers WHERE customerID = ?;'

    db.pool.query(delete_customer, [customerID], function(error, rows, fields){
        if (error) {
            console.log(error);
            res.sendStatus(400);
        }

    } )
})


app.put('/put-person-ajax', function(req, res, next){
    let data = req.body;

    let customer = parseInt(data.fullname)
    let email = data.email
    let phonenumber = parseInt(data.phonenumber)

    let query_update_customer = 'UPDATE Customers SET email = ?, phoneNumber = ? WHERE Customers.customerID = ?';

    db.pool.query(query_update_customer, [email, phonenumber, customer], function(error, rows, fields){
        if (error){
            console.log(error);
            res.sendStatus(400);
        }
        else{
            console.log("succeeded")
        }
    })

})

app.get('/orders', function(req, res) {
    let get_orders_table_query = "SELECT * FROM Orders";

    db.pool.query(get_orders_table_query, function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            res.render("orders", { data: rows });
        }
    });
});

app.post('/add-order-ajax', function(req, res) {
    let data = req.body;

    // Insert validation here

    let add_order_query = `INSERT INTO Orders (customerID, shipped, vehicle_VIN, price, warranty) VALUES (?, ?, ?, ?, ?)`;

    db.pool.query(add_order_query, [data.customerID, data.shipped, data.vehicle_VIN, data.price, data.warranty], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            let get_orders_table_query = "SELECT * FROM Orders";
            db.pool.query(get_orders_table_query, function(error, rows, fields) {
                if (error) {
                    console.log(error);
                    res.sendStatus(400);
                } else {
                    res.send(rows);
                }
            });
        }
    });
});

app.delete('/delete-order-ajax', function(req, res, next) {
    let data = req.body;
    let orderID = parseInt(data.id);
    let delete_order = 'DELETE FROM Orders WHERE orderID = ?';

    db.pool.query(delete_order, [orderID], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            res.sendStatus(200);
        }
    });
});

app.put('/update-order-ajax', function(req, res, next) {
    let data = req.body;

    let orderID = parseInt(data.orderID);
    let shipped = data.shipped;
    let price = parseFloat(data.price);

    let query_update_order = 'UPDATE Orders SET shipped = ?, price = ? WHERE orderID = ?';

    db.pool.query(query_update_order, [shipped, price, orderID], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            console.log("Order updated successfully");
            res.sendStatus(200);
        }
    });
});


app.get('/transactions', function(req, res) {
    let get_transactions_table_query = "SELECT * FROM Transactions";

    db.pool.query(get_transactions_table_query, function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            res.render("transactions", { data: rows });
        }
    });
});

app.post('/add-transaction-ajax', function(req, res) {
    let data = req.body;

    // Insert validation here

    let add_transaction_query = `INSERT INTO Transactions (orderID, orderAge, transactionDate, total, shipped) VALUES (?, ?, ?, ?, ?)`;

    db.pool.query(add_transaction_query, [data.orderID, data.orderAge, data.transactionDate, data.total, data.shipped], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            let get_transactions_table_query = "SELECT * FROM Transactions";
            db.pool.query(get_transactions_table_query, function(error, rows, fields) {
                if (error) {
                    console.log(error);
                    res.sendStatus(400);
                } else {
                    res.send(rows);
                }
            });
        }
    });
});

app.delete('/delete-transaction-ajax', function(req, res, next) {
    let data = req.body;
    let orderID = parseInt(data.id);
    let delete_transaction = 'DELETE FROM Transactions WHERE orderID = ?';

    db.pool.query(delete_transaction, [orderID], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            res.sendStatus(200);
        }
    });
});

app.put('/update-transaction-ajax', function(req, res, next) {
    let data = req.body;

    let orderID = parseInt(data.orderID);
    let orderAge = parseInt(data.orderAge);
    let total = parseFloat(data.total);
    let shipped = data.shipped;

    let query_update_transaction = 'UPDATE Transactions SET orderAge = ?, total = ?, shipped = ? WHERE orderID = ?';

    db.pool.query(query_update_transaction, [orderAge, total, shipped, orderID], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            console.log("Transaction updated successfully");
            res.sendStatus(200);
        }
    });
});


app.get('/warranties', function(req, res) {
    let get_warranties_table_query = "SELECT * FROM Warranties";

    db.pool.query(get_warranties_table_query, function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            res.render("warranties", { data: rows });
        }
    });
});

app.post('/add-warranty-ajax', function(req, res) {
    let data = req.body;

    // Insert validation here

    let add_warranty_query = `INSERT INTO Warranties (orderID, detailsID) VALUES (?, ?)`;

    db.pool.query(add_warranty_query, [data.orderID, data.detailsID], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            let get_warranties_table_query = "SELECT * FROM Warranties";
            db.pool.query(get_warranties_table_query, function(error, rows, fields) {
                if (error) {
                    console.log(error);
                    res.sendStatus(400);
                } else {
                    res.send(rows);
                }
            });
        }
    });
});

app.delete('/delete-warranty-ajax', function(req, res, next) {
    let data = req.body;
    let warrantyID = parseInt(data.id);
    let delete_warranty = 'DELETE FROM Warranties WHERE warrantyID = ?';

    db.pool.query(delete_warranty, [warrantyID], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            res.sendStatus(200);
        }
    });
});

app.put('/update-warranty-ajax', function(req, res, next) {
    let data = req.body;

    let warrantyID = parseInt(data.warrantyID);
    let orderID = parseInt(data.orderID);
    let detailsID = parseInt(data.detailsID);

    let query_update_warranty = 'UPDATE Warranties SET orderID = ?, detailsID = ? WHERE warrantyID = ?';

    db.pool.query(query_update_warranty, [orderID, detailsID, warrantyID], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            console.log("Warranty updated successfully");
            res.sendStatus(200);
        }
    });
});


app.get('/warrantyDetails', function(req, res) {
    let get_warrantyDetails_table_query = "SELECT * FROM WarrantyDetails";

    db.pool.query(get_warrantyDetails_table_query, function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            res.render("warrantyDetails", { data: rows });
        }
    });
});

app.post('/add-warrantyDetail-ajax', function(req, res) {
    let data = req.body;

    // Insert validation here

    let add_warrantyDetail_query = `INSERT INTO WarrantyDetails (id, ItemToBeCovered, endCoverageDate) VALUES (?, ?, ?)`;

    db.pool.query(add_warrantyDetail_query, [data.id, data.ItemToBeCovered, data.endCoverageDate], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            let get_warrantyDetails_table_query = "SELECT * FROM WarrantyDetails";
            db.pool.query(get_warrantyDetails_table_query, function(error, rows, fields) {
                if (error) {
                    console.log(error);
                    res.sendStatus(400);
                } else {
                    res.send(rows);
                }
            });
        }
    });
});

app.delete('/delete-warrantyDetail-ajax', function(req, res, next) {
    let data = req.body;
    let id = parseInt(data.id);
    let delete_warrantyDetail = 'DELETE FROM WarrantyDetails WHERE id = ?';

    db.pool.query(delete_warrantyDetail, [id], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            res.sendStatus(200);
        }
    });
});

app.put('/update-warrantyDetail-ajax', function(req, res, next) {
    let data = req.body;

    let id = parseInt(data.id);
    let ItemToBeCovered = data.ItemToBeCovered;
    let endCoverageDate = data.endCoverageDate;

    let query_update_warrantyDetail = 'UPDATE WarrantyDetails SET ItemToBeCovered = ?, endCoverageDate = ? WHERE id = ?';

    db.pool.query(query_update_warrantyDetail, [ItemToBeCovered, endCoverageDate, id], function(error, rows, fields) {
        if (error) {
            console.log(error);
            res.sendStatus(400);
        } else {
            console.log("Warranty Detail updated successfully");
            res.sendStatus(200);
        }
    });
});





/*
    LISTENER
*/
app.listen(PORT, function(){            // This is the basic syntax for what is called the 'listener' which receives incoming requests on the specified PORT.
    console.log('Express started on http://localhost:' + PORT + '; press Ctrl-C to terminate.')
});