// Get the form element we need to modify
let updateVehicleForm = document.getElementById('update-vehicle-form-ajax');

// Modify the form to handle submission
updateVehicleForm.addEventListener("submit", function (e) {
    // Prevent the form from submitting the default way
    e.preventDefault();

    // Get the form fields we need to get data from
    let inputVIN = document.getElementById("mySelectVIN");
    let inputMake = document.getElementById("update-make");
    let inputModel = document.getElementById("update-model");
    let inputYear = document.getElementById("update-year");
    let inputEngine = document.getElementById("update-engine");
    let inputAllWheelDrive = document.getElementById('update-allWheelDrive');
    let input4x4 = document.getElementById('update-4x4');
    let inputElectricDriveTrain = document.getElementById('update-electricDriveTrain');
    let inputColor = document.getElementById("update-color");

    // Get the values from the form fields
    let vinValue = inputVIN.value;
    let makeValue = inputMake.value;
    let modelValue = inputModel.value;
    let yearValue = inputYear.value;
    let engineValue = inputEngine.value;
    let allWheelDriveValue = inputAllWheelDrive;
    let fourByFourValue = input4x4;
    let electricDriveTrainValue = inputElectricDriveTrain;
    let colorValue = inputColor.value;

    // Put our data into a JavaScript object
    let data = {
        VIN: vinValue,
        make: makeValue,
        model: modelValue,
        year: yearValue,
        engine: engineValue,
        allWheelDrive: allWheelDriveValue,
        '4x4': fourByFourValue,
        electricDriveTrain: electricDriveTrainValue,
        color: colorValue
    };

    // Setup our AJAX request
    var xhttp = new XMLHttpRequest();
    xhttp.open("PUT", "/put-vehicle-ajax", true);
    xhttp.setRequestHeader("Content-type", "application/json");

    // Define what to do when the AJAX request state changes
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            // Update the row in the table with the new data
            updateRow(xhttp.response, vinValue);

            // Clear the input fields
            inputVIN.value = '';
            inputMake.value = '';
            inputModel.value = '';
            inputYear.value = '';
            inputEngine.value = '';
            inputColor.value = '';
        } else if (xhttp.readyState == 4 && xhttp.status != 200) {
            console.log("There was an error with the input.");
        }
    };

    // Send the AJAX request with the data
    xhttp.send(JSON.stringify(data));
});

// Function to update a row in the table with the new vehicle data
function updateRow(data, vin) {
    let parsedData = JSON.parse(data);
    
    let table = document.getElementById("vehicles-table");

    for (let i = 0, row; row = table.rows[i]; i++) {
        // Iterate through rows
        if (table.rows[i].getAttribute("data-value") == vin) {
            // Get the location of the row where we found the matching VIN
            let updateRowIndex = table.getElementsByTagName("tr")[i];

            // Update each cell with the new data
            updateRowIndex.getElementsByTagName("td")[1].innerHTML = parsedData[0].make;
            updateRowIndex.getElementsByTagName("td")[2].innerHTML = parsedData[0].model;
            updateRowIndex.getElementsByTagName("td")[3].innerHTML = parsedData[0].year;
            updateRowIndex.getElementsByTagName("td")[4].innerHTML = parsedData[0].engine;
            updateRowIndex.getElementsByTagName("td")[5].innerHTML = parsedData[0].allWheelDrive;
            updateRowIndex.getElementsByTagName("td")[6].innerHTML = parsedData[0]['4x4'];
            updateRowIndex.getElementsByTagName("td")[7].innerHTML = parsedData[0].electricDriveTrain;
            updateRowIndex.getElementsByTagName("td")[8].innerHTML = parsedData[0].color;
        }
    }
}
