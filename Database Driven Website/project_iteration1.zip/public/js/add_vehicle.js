// Get the form element we need to modify
let addVehicleForm = document.getElementById('add-vehicle-form-ajax');

// Modify the form to handle submission
addVehicleForm.addEventListener("submit", function (e) {
    // Prevent the form from submitting the default way
    e.preventDefault();

    // Get the form fields we need to get data from
    let inputVIN = document.getElementById("input-vin");
    let inputMake = document.getElementById("input-make");
    let inputModel = document.getElementById("input-model");
    let inputYear = document.getElementById("input-year");
    let inputEngine = document.getElementById("input-engine");
    let inputAllWheelDrive= (document.getElementById('input-allWheelDrive'));
    let input4x4 = (document.getElementById('input-4x4'));
    let inputElectricDriveTrain = (document.getElementById('input-electricDriveTrain'));

    console.log(inputElectricDriveTrain)
    console.log(inputAllWheelDrive)
    console.log(input4x4)

    let inputColor = document.getElementById("input-color");

    // Get the values from the form fields
    let vinValue = inputVIN.value;
    let makeValue = inputMake.value;
    let modelValue = inputModel.value;
    let yearValue = inputYear.value;
    let engineValue = inputEngine.value;
    let allWheelDriveValue = inputAllWheelDrive.value;
    let fourByFourValue = input4x4.value;
    let electricDriveTrainValue = inputElectricDriveTrain.value;
    let colorValue = inputColor.value;

    // Put our data into a JavaScript object
    let data = {
        VIN: vinValue,
        make: makeValue,
        model: modelValue,
        year: yearValue,
        engine: engineValue,
        allWheelDrive: allWheelDriveValue,
        '4x4': parseInt(fourByFourValue),
        electricDriveTrain: electricDriveTrainValue,
        color: colorValue
    };
    console.log(fourByFourValue)

    console.log(data)


    // Setup our AJAX request
    var xhttp = new XMLHttpRequest();
    xhttp.open("POST", "/add-vehicle-ajax", true);
    xhttp.setRequestHeader("Content-type", "application/json");

    // Define what to do when the AJAX request state changes
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            // Add the new data to the table
            addRowToTable(xhttp.response);

            // Clear the input fields
            inputVIN.value = '';
            inputMake.value = '';
            inputModel.value = '';
            inputYear.value = '';
            inputEngine.value = '';
            inputAllWheelDrive.value = '';
            input4x4.value = '';
            inputElectricDriveTrain.value = '';
            inputColor.value = '';
        } else if (xhttp.readyState == 4 && xhttp.status != 200) {
            console.log("There was an error with the input.");
        }
    };

    // Send the AJAX request with the data
    xhttp.send(JSON.stringify(data));
});

// Function to add a row to the table with the new vehicle data
function addRowToTable(data) {
    // Get a reference to the table
    let currentTable = document.getElementById("vehicles-table");

    // Parse the response data
    let parsedData = JSON.parse(data);
    console.log(parsedData)
    console.log(data)

    // Create a row and cells
    let row = document.createElement("TR");
    let vinCell = document.createElement("TD");
    let makeCell = document.createElement("TD");
    let modelCell = document.createElement("TD");
    let yearCell = document.createElement("TD");
    let engineCell = document.createElement("TD");
    let allWheelDriveCell = document.createElement("TD");
    let fourByFourCell = document.createElement("TD");
    let electricDriveTrainCell = document.createElement("TD");
    let colorCell = document.createElement("TD");
    let deleteCell = document.createElement("TD");

    // Append cells to row
    row.appendChild(vinCell);
    row.appendChild(makeCell);
    row.appendChild(modelCell);
    row.appendChild(yearCell);
    row.appendChild(engineCell);
    row.appendChild(allWheelDriveCell);
    row.appendChild(fourByFourCell);
    row.appendChild(electricDriveTrainCell);
    row.appendChild(colorCell);
    row.appendChild(deleteCell);

    // Append row to table
    currentTable.appendChild(row);
}