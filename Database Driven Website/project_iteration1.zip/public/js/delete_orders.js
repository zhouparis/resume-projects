function deleteOrder(orderID) {
    let link = '/delete-order-ajax/';
    let data = {
        id: orderID
    };

    $.ajax({
        url: link,
        type: 'DELETE',
        data: JSON.stringify(data),
        contentType: "application/json; charset=utf-8",
        success: function(result) {
            deleteRow(orderID);
        },
        error: function(xhr, status, error) {
            console.error("Error deleting order:", error);
        }
    });
}

function deleteRow(orderID) {
    let table = document.getElementById("orders-table");
    for (let i = 0, row; row = table.rows[i]; i++) {
        if (table.rows[i].getAttribute("data-value") == orderID) {
            table.deleteRow(i);
            deleteDropDownMenu(orderID);
            break;
        }
    }
}

function deleteDropDownMenu(orderID) {
    let selectMenu = document.getElementById("orderSelect");
    for (let i = 0; i < selectMenu.length; i++) {
        if (Number(selectMenu.options[i].value) === Number(orderID)) {
            selectMenu.remove(i);
            break;
        }
    }
}
