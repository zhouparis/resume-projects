// Get the objects we need to modify
let updateOrderForm = document.getElementById('update-order-form-ajax');

// Modify the objects we need
updateOrderForm.addEventListener("submit", function (e) {
   
    // Prevent the form from submitting
    e.preventDefault();

    // Get form fields we need to get data from
    let inputOrderID = document.getElementById("order-select");
    let inputShipped = document.getElementById("update-shipped");
    let inputVehicleVIN = document.getElementById("update-vehicle-VIN");
    let inputPrice = document.getElementById("update-price");
    let inputWarranty = document.getElementById("update-warranty");

    // Get the values from the form fields
    let orderIDValue = inputOrderID.value;
    let shippedValue = inputShipped.checked;
    let vehicleVINValue = inputVehicleVIN.value;
    let priceValue = parseFloat(inputPrice.value);
    let warrantyValue = inputWarranty.checked;

    // Validate inputs
    if (isNaN(priceValue) || priceValue < 0) {
        console.log("Invalid price value");
        return;
    }

    // Put our data we want to send in a JavaScript object
    let data = {
        orderID: orderIDValue,
        shipped: shippedValue,
        vehicleVIN: vehicleVINValue,
        price: priceValue,
        warranty: warrantyValue
    }
    
    // Setup our AJAX request
    var xhttp = new XMLHttpRequest();
    xhttp.open("PUT", "/update-order-ajax", true);
    xhttp.setRequestHeader("Content-type", "application/json");

    // Tell our AJAX request how to resolve
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) {

            // Update the row in the table
            updateRow(xhttp.response, orderIDValue);

            // Clear the input fields for another transaction
            inputOrderID.value = '';
            inputShipped.checked = false;
            inputVehicleVIN.value = '';
            inputPrice.value = '';
            inputWarranty.checked = false;
        }
        else if (xhttp.readyState == 4 && xhttp.status != 200) {
            console.log("There was an error with the input.")
        }
    }

    // Send the request and wait for the response
    xhttp.send(JSON.stringify(data));

})

// Function to update the row in the table
function updateRow(data, orderID){
    let parsedData = JSON.parse(data);
    
    let table = document.getElementById("orders-table");

    for (let i = 0, row; row = table.rows[i]; i++) {
       // Iterate through rows
       if (table.rows[i].getAttribute("data-value") == orderID) {

            // Get the location of the row where we found the matching order ID
            let updateRowIndex = table.getElementsByTagName("tr")[i];

            // Update table cells with new values
            let cells = updateRowIndex.getElementsByTagName("td");
            cells[1].innerHTML = parsedData.orderID; // Assuming orderID is in the second cell
            cells[2].innerHTML = parsedData.shipped; // Assuming shipped is in the third cell
            cells[3].innerHTML = parsedData.vehicle_VIN; // Assuming vehicle_VIN is in the fourth cell
            cells[4].innerHTML = parsedData.price; // Assuming price is in the fifth cell
            cells[5].innerHTML = parsedData.warranty; // Assuming warranty is in the sixth cell
       }
    }
}
