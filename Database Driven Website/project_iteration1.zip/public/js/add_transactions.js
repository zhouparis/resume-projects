// Get the objects we need to modify
let addWarrantyForm = document.getElementById('add-warranty-form-ajax');

// Modify the objects we need
addWarrantyForm.addEventListener("submit", function (e) {
    
    // Prevent the form from submitting
    e.preventDefault();

    // Get form fields we need to get data from
    let inputOrderID = document.getElementById("input-orderID");
    let inputDetailsID = document.getElementById("input-detailsID");

    // Get the values from the form fields
    let orderIDValue = inputOrderID.value;
    let detailsIDValue = inputDetailsID.value;

    // Put our data we want to send in a JavaScript object
    let data = {
        orderID: orderIDValue,
        detailsID: detailsIDValue
    }

    // Setup our AJAX request
    var xhttp = new XMLHttpRequest();
    xhttp.open("POST", "/add-warranty-ajax", true);
    xhttp.setRequestHeader("Content-type", "application/json");

    // Tell our AJAX request how to resolve
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) {

            // Add the new data to the table
            addRowToTable(xhttp.response);

            // Clear the input fields for another transaction
            inputOrderID.value = '';
            inputDetailsID.value = '';
        }
        else if (xhttp.readyState == 4 && xhttp.status != 200) {
            console.log("There was an error with the input.")
        }
    }

    // Send the request and wait for the response
    xhttp.send(JSON.stringify(data));

})


// Creates a single row from an Object representing a single record from the warranties
addRowToTable = (data) => {

    // Get a reference to the current table on the page
    let currentTable = document.getElementById("warranties-table");

    // Get a reference to the new row from the database query
    let parsedData = JSON.parse(data);
    let newRow = parsedData[parsedData.length - 1];
    
    // Create a row and 4 cells
    let row = document.createElement("TR");
    let orderIDCell = document.createElement("TD");
    let detailsIDCell = document.createElement("TD");
    let deleteCell = document.createElement("TD");

    // Fill the cells with correct data
    orderIDCell.innerText = newRow.orderID;
    detailsIDCell.innerText = newRow.detailsID;
    
    deleteCell = document.createElement("button");
    deleteCell.innerHTML = "Delete";
    deleteCell.onclick = function(){
        deleteWarranty(newRow.orderID, newRow.detailsID);
    }

    // Add the cells to the row 
    row.appendChild(orderIDCell);
    row.appendChild(detailsIDCell);
    row.appendChild(deleteCell);

    row.setAttribute('data-value', newRow.orderID);

    // Add the row to the table
    currentTable.appendChild(row);

    // Update any relevant dropdowns or select elements if needed
    let selectMenu = document.getElementById("warrantySelect");
    let option = document.createElement("option");
    option.text = newRow.orderID;
    option.value = newRow.orderID;
    selectMenu.add(option);
    
}
