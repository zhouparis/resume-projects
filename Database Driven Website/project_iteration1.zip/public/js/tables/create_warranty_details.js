function create_warranty_details_table(db) {
    // Define SQL statements to create and populate the WarrantyDetails table
    let drop_warranty_details = "DROP TABLE IF EXISTS WarrantyDetails;";
    
    let create_warranty_details = `CREATE TABLE WarrantyDetails ( \
        id int NOT NULL, \
        ItemToBeCovered varchar(145), \
        endCoverageDate datetime NOT NULL, \
        PRIMARY KEY (id), \
        FOREIGN KEY (id) REFERENCES Warranties(detailsID) ON DELETE CASCADE \
    );`;

    let insert_warranty_details = ` \
        INSERT INTO WarrantyDetails (id, ItemToBeCovered, endCoverageDate) \
        SELECT  \
            Warranties.detailsID AS id, \
            'Engine' AS ItemToBeCovered, \
            '2026-01-01 23:59:59' AS endCoverageDate \
        FROM Warranties \
        JOIN Orders ON Warranties.orderID = Orders.orderID \
        WHERE Orders.vehicle_VIN = 'JN6MD06S2BW031939'; \
        INSERT INTO WarrantyDetails (id, ItemToBeCovered, endCoverageDate) \
        SELECT  \
            Warranties.detailsID AS id, \
            'Drive Train' AS ItemToBeCovered, \
            '2027-01-01 23:59:59' AS endCoverageDate \
        FROM Warranties \
        JOIN Orders ON Warranties.orderID = Orders.orderID \
        WHERE Orders.vehicle_VIN = 'JH4DB1550LS000111'; \
        INSERT INTO WarrantyDetails (id, ItemToBeCovered, endCoverageDate) \
        SELECT  \
            Warranties.detailsID AS id, \
            'Body' AS ItemToBeCovered, \
            '2025-01-01 23:59:59' AS endCoverageDate \
        FROM Warranties \
        JOIN Orders ON Warranties.orderID = Orders.orderID \
        WHERE Orders.vehicle_VIN = '1JCCM85E5BT001312'; \
        `;


    // Execute SQL statements
    db.pool.query(drop_warranty_details, function(err) {
        if (err) throw err;
        db.pool.query(create_warranty_details, function(err) {
            if (err) throw err;
            db.pool.query(insert_warranty_details, function(err) {
                if (err) throw err;
                console.log("Successfully created WarrantyDetails Table and inserted sample data.");
            });
        });
    });
}

module.exports = create_warranty_details_table;
