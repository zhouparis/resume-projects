function create_orders_table(db) {
    let drop_orders = "DROP TABLE IF EXISTS orders;"
    let create_orders = "CREATE TABLE Orders(  \
    orderID int AUTO_INCREMENT UNIQUE NOT NULL, \
    customerID int UNIQUE NOT NULL, \
    shipped boolean NOT NULL DEFAULT 0, \
    vehicle_VIN varchar(145) NOT NULL, \
    price float NOT NULL, \
    warranty boolean DEFAULT 0, \
    PRIMARY KEY (orderID),  \
    FOREIGN KEY (customerID) REFERENCES Customers(customerID) ON DELETE CASCADE, \
    FOREIGN KEY (vehicle_VIN) REFERENCES Vehicles(VIN) ON DELETE CASCADE \
);"

    let insert_orders = `INSERT INTO Orders (customerID, price, vehicle_VIN, warranty) \
SELECT  \
    Customers.customerID, \
    30000,  \
    Vehicles.VIN, \
    1 \
FROM  \
    Customers \
JOIN  \
    Vehicles \
ON  \
    Customers.name = 'Paris' AND Vehicles.make = 'Subaru';`


    db.pool.query(drop_orders, function (err, results, fields) {
        db.pool.query(create_orders, function (err, results, fields) {
            db.pool.query(insert_orders, function (err, results, fields) {
                console.log("successfully created Orders Table")
            })
        })
    })


}

module.exports = create_orders_table;
