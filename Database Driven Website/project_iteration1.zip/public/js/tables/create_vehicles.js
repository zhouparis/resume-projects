function create_vehicles_table(db) {
    let drop_vehicles = "DROP TABLE IF EXISTS Vehicles;";
    
    let create_vehicles = `CREATE TABLE Vehicles ( \
        VIN varchar(140) UNIQUE NOT NULL, \
        make varchar(140) NOT NULL, \
        model varchar(140) NOT NULL, \
        year varchar(4) NOT NULL, \
        engine varchar(140) NOT NULL, \
        allWheelDrive boolean DEFAULT 0, \
        4x4 boolean DEFAULT 0, \
        electricDriveTrain boolean DEFAULT 0, \
        color varchar(140) NOT NULL, \
        PRIMARY KEY (VIN) \
    );`;


    let insert_vehicles = `INSERT INTO Vehicles ( \
        VIN, make, model, year, engine, allWheelDrive, 4x4, electricDriveTrain, color \
        ) VALUES  \
        ("JN6MD06S2BW031939", "Subaru", "Impreza", "2008", "4-CYL, 2.0L", 1, 0, 0, "black"), \
        ("JH4DB1550LS000111", "Honda", "Civic", "2019", "4-cyl, Turbo Gas, 1.5L", 0, 0, 0, "white"), \
        ("JH4KA4571LC033593", "Tesla", "Model 3", "2018", "electric", 0, 0, 1, "blue"), \
        ("1JCCM85E5BT001312", "Jeep", "Wrangler", "2013", "6-Cylinder, 3.6L", 0, 1, 0, "grey");`;


    db.pool.query("SET FOREIGN_KEY_CHECKS=0;", function(err, results, fields){
        db.pool.query(drop_vehicles, function(err, results, fields) {
            if (err) throw err;
            db.pool.query(create_vehicles, function(err, results, fields) {
                if (err) throw err;
                db.pool.query(insert_vehicles, function(err, results, fields) {
                    if (err) throw err;
                    console.log("Successfully created Vehicles Table and inserted sample data.");
                });
            });
        });
    });
}

module.exports = create_vehicles_table;
