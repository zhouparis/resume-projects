function create_warranties_table(db) {
    // Define SQL statements to create and populate the Warranties table
    let drop_warranties = "DROP TABLE IF EXISTS Warranties;";
    
    let create_warranties = `CREATE TABLE Warranties (
        warrantyID INT AUTO_INCREMENT NOT NULL,
        orderID INT NOT NULL,
        detailsID INT UNIQUE NOT NULL,
        FOREIGN KEY (orderID) REFERENCES Orders(orderID) ON DELETE CASCADE,
        PRIMARY KEY (warrantyID, orderID)
    );`;

    let insert_warranties = `
        INSERT INTO Warranties (detailsID, orderID)
        SELECT 
            111 AS detailsID,
            Orders.orderID
        FROM Orders
        WHERE Orders.vehicle_VIN = 'JN6MD06S2BW031939';

        INSERT INTO Warranties (detailsID, orderID)
        SELECT 
            222 AS detailsID,
            Orders.orderID
        FROM Orders
        WHERE Orders.vehicle_VIN = 'JH4DB1550LS000111';

        INSERT INTO Warranties (detailsID, orderID)
        SELECT 
            333 AS detailsID,
            Orders.orderID
        FROM Orders
        WHERE Orders.vehicle_VIN = '1JCCM85E5BT001312';
    `;

    // Execute SQL statements
    db.pool.query(drop_warranties, function(err) {
        if (err) throw err;
        db.pool.query(create_warranties, function(err) {
            if (err) throw err;
            db.pool.query(insert_warranties, function(err) {
                if (err) throw err;
                console.log("Successfully created Warranties Table and inserted sample data.");
            });
        });
    });
}

module.exports = create_warranties_table;
