
function create_transactions_table(db) {
    let drop_transactions = "DROP TABLE IF EXISTS transactions;"
    let create_transactions = "CREATE TABLE Transactions ( \
    orderID int UNIQUE NOT NULL, \
    orderAge int NOT NULL, \
    transactionDate datetime NOT NULL, \
    total float NOT NULL, \
    shipped boolean NOT NULL DEFAULT 0, \
    PRIMARY KEY (orderID), \
    FOREIGN KEY (orderID) REFERENCES Orders(orderID) ON DELETE CASCADE \
);"

    let insert_transactions = `INSERT INTO transactions (customerID, price, vehicle_VIN, warranty) \
SELECT  \
    Customers.customerID, \
    30000,  \
    Vehicles.VIN, \
    1 \
FROM  \
    Customers \
JOIN  \
    Vehicles \
ON  \
    Customers.name = 'Paris' AND Vehicles.make = 'Subaru';`


    db.pool.query(drop_transactions, function (err, results, fields) {
        db.pool.query(create_transactions, function (err, results, fields) {
            db.pool.query(insert_transactions, function (err, results, fields) {
                console.log("successfully created transactions Table")
            })
        })
    })


}

module.exports = create_transactions_table;
