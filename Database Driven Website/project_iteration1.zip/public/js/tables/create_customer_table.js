
function create_customers_table(db) {
    let drop_customers = "DROP TABLE IF EXISTS Customers;"
    let create_customers = "CREATE TABLE Customers( \
    customerID int UNIQUE NOT NULL AUTO_INCREMENT, \
    name varchar(145) NOT NULL, \
    email varchar(145) NOT NULL, \
    phoneNumber varchar(145) NOT NULL, \
    patron boolean DEFAULT 0, \
    PRIMARY KEY (customerID) \
);"

    let insert_customers = `INSERT INTO Customers( \
        name, \
        email, \
        phoneNumber, \
        patron \
    ) VALUES  \
    ("David", "willnerd@oregonstate.edu", "7774442222", 0), \
    ("Paris", "zhoudp@oregonstate.edu", "1112223333", 0), \
    ("Greg", "atkinsg@oregonstate.edu", "6667778888", 1);`


    db.pool.query(drop_customers, function(err, results, fields){
        db.pool.query(create_customers, function(err, results, fields){
            db.pool.query(insert_customers, function(err, results, fields){
                console.log("successfully created Customer Table")
                })
            })
        })
    }
;

module.exports = create_customers_table;