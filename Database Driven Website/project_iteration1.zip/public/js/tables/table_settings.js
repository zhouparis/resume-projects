function mysql_setup(db){
    db.pool.query("SET FOREIGN_KEY_CHECKS=0;")
    db.pool.query("SET AUTOCOMMIT = 0;")
    console.log("Turned off Forign key checks")
}

module.exports = mysql_setup