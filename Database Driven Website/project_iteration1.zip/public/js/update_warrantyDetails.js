// Get the objects we need to modify
let updateWarrantyDetailsForm = document.getElementById('update-warranty-details-form-ajax');

// Modify the objects we need
updateWarrantyDetailsForm.addEventListener("submit", function (e) {
   
    // Prevent the form from submitting
    e.preventDefault();

    // Get form fields we need to get data from
    let inputWarrantyID = document.getElementById("warranty-select");
    let inputItemToBeCovered = document.getElementById("update-item-to-be-covered");
    let inputEndCoverageDate = document.getElementById("update-end-coverage-date");

    // Get the values from the form fields
    let warrantyIDValue = inputWarrantyID.value;
    let itemToBeCoveredValue = inputItemToBeCovered.value;
    let endCoverageDateValue = inputEndCoverageDate.value;

    // Validate the input
    if (!warrantyIDValue || !itemToBeCoveredValue || !endCoverageDateValue) {
        console.log("All fields are required.");
        return;
    }

    // Put our data we want to send in a JavaScript object
    let data = {
        itemToBeCovered: itemToBeCoveredValue,
        endCoverageDate: endCoverageDateValue
    }
    
    // Setup our AJAX request
    var xhttp = new XMLHttpRequest();
    xhttp.open("PUT", "/update-warranty-details-ajax", true);
    xhttp.setRequestHeader("Content-type", "application/json");

    // Tell our AJAX request how to resolve
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            // Add the new data to the table
            updateRow(xhttp.response, warrantyIDValue);

            // Clear the input fields for another transaction
            inputItemToBeCovered.value = '';
            inputEndCoverageDate.value = '';
        }
        else if (xhttp.readyState == 4 && xhttp.status != 200) {
            console.log("There was an error with the input.");
        }
    }

    // Send the request and wait for the response
    xhttp.send(JSON.stringify(data));
})

// Function to update the row in the table
function updateRow(data, warrantyID) {
    let parsedData = JSON.parse(data);
    
    let table = document.getElementById("warranty-details-table");

    for (let i = 0, row; row = table.rows[i]; i++) {
        // Iterate through rows
        if (table.rows[i].getAttribute("data-value") == warrantyID) {

            // Get the location of the row where we found the matching warranty ID
            let updateRowIndex = table.getElementsByTagName("tr")[i];

            // Update the relevant cells with new data
            let itemCell = updateRowIndex.getElementsByTagName("td")[1];
            let dateCell = updateRowIndex.getElementsByTagName("td")[2];

            itemCell.innerHTML = parsedData.itemToBeCovered; 
            dateCell.innerHTML = parsedData.endCoverageDate; 
        }
    }
}