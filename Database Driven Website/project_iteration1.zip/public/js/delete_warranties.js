function deleteWarranty(warrantyID, orderID) {
    let link = '/delete-warranty-ajax/';
    let data = {
        warrantyID: warrantyID,
        orderID: orderID
    };

    $.ajax({
        url: link,
        type: 'DELETE',
        data: JSON.stringify(data),
        contentType: "application/json; charset=utf-8",
        success: function(result) {
            deleteRow(warrantyID, orderID);
        },
        error: function(xhr, status, error) {
            console.error("Error deleting warranty:", error);
        }
    });
}

function deleteRow(warrantyID, orderID) {
    let table = document.getElementById("warranties-table");
    for (let i = 0, row; row = table.rows[i]; i++) {
        // Use the `warrantyID` and `orderID` to find the correct row
        if (table.rows[i].getAttribute("data-warranty-id") == warrantyID && table.rows[i].getAttribute("data-order-id") == orderID) {
            table.deleteRow(i);
            deleteDropDownMenu(warrantyID);
            break;
        }
    }
}

function deleteDropDownMenu(warrantyID) {
    let selectMenu = document.getElementById("warrantySelect");
    for (let i = 0; i < selectMenu.length; i++) {
        if (Number(selectMenu.options[i].value) === Number(warrantyID)) {
            selectMenu.remove(i);
            break;
        }
    }
}
