// Get the objects we need to modify
let updateTransactionForm = document.getElementById('update-transaction-form-ajax');

// Modify the objects we need
updateTransactionForm.addEventListener("submit", function (e) {
   
    // Prevent the form from submitting
    e.preventDefault();

    // Get form fields we need to get data from
    let inputOrderID = document.getElementById("order-select");
    let inputOrderAge = document.getElementById("update-orderage");
    let inputTransactionDate = document.getElementById("update-transactiondate");
    let inputTotal = document.getElementById("update-total");
    let inputShipped = document.getElementById("update-shipped");

    // Get the values from the form fields
    let orderIDValue = inputOrderID.value;
    let orderAgeValue = parseInt(inputOrderAge.value);
    let transactionDateValue = new Date(inputTransactionDate.value).toISOString(); // Ensure date format is correct
    let totalValue = parseFloat(inputTotal.value);
    let shippedValue = inputShipped.checked; // Assuming this is a checkbox

    // Check if the total and order age are valid
    if (isNaN(orderAgeValue) || isNaN(totalValue)) {
        console.log("Invalid input values.");
        return;
    }

    // Put our data we want to send in a javascript object
    let data = {
        orderID: orderIDValue,
        orderAge: orderAgeValue,
        transactionDate: transactionDateValue,
        total: totalValue,
        shipped: shippedValue
    };
    
    // Setup our AJAX request
    var xhttp = new XMLHttpRequest();
    xhttp.open("PUT", "/update-transaction-ajax", true);
    xhttp.setRequestHeader("Content-type", "application/json");

    // Tell our AJAX request how to resolve
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) {

            // Add the new data to the table
            updateRow(xhttp.response, orderIDValue);

            // Clear the input fields for another transaction
            inputOrderID.value = '';
            inputOrderAge.value = '';
            inputTransactionDate.value = '';
            inputTotal.value = '';
            inputShipped.checked = false;
        }
        else if (xhttp.readyState == 4 && xhttp.status != 200) {
            console.log("There was an error with the input.");
        }
    };

    // Send the request and wait for the response
    xhttp.send(JSON.stringify(data));

});

function updateRow(data, orderID) {
    let parsedData = JSON.parse(data);
    
    let table = document.getElementById("transactions-table");

    for (let i = 0, row; row = table.rows[i]; i++) {
        if (table.rows[i].getAttribute("data-value") == orderID) {

            // Get the location of the row where we found the matching order ID
            let updateRowIndex = table.getElementsByTagName("tr")[i];

            // Update the cells with the new data
            let cells = updateRowIndex.getElementsByTagName("td");

            cells[1].innerHTML = parsedData[0].orderAge; // Assuming this is the 'orderAge' column
            cells[2].innerHTML = new Date(parsedData[0].transactionDate).toLocaleDateString(); // Assuming this is the 'transactionDate' column
            cells[3].innerHTML = parsedData[0].total; // Assuming this is the 'total' column
            cells[4].innerHTML = parsedData[0].shipped ? 'Yes' : 'No'; // Assuming this is the 'shipped' column
        }
    }
}
