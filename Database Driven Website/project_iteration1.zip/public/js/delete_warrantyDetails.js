function deleteWarrantyDetail(id) {
    let link = '/delete-warrantydetail-ajax/';
    let data = {
        id: id
    };

    $.ajax({
        url: link,
        type: 'DELETE',
        data: JSON.stringify(data),
        contentType: "application/json; charset=utf-8",
        success: function(result) {
            deleteRow(id);
        },
        error: function(xhr, status, error) {
            console.error("Error deleting warranty detail:", error);
        }
    });
}

function deleteRow(id) {
    let table = document.getElementById("warrantydetails-table");
    for (let i = 0, row; row = table.rows[i]; i++) {
        // Check for matching id in the table row's data attribute
        if (table.rows[i].getAttribute("data-id") == id) {
            table.deleteRow(i);
            deleteDropDownMenu(id);
            break;
        }
    }
}

function deleteDropDownMenu(id) {
    let selectMenu = document.getElementById("warrantyDetailSelect");
    for (let i = 0; i < selectMenu.length; i++) {
        if (Number(selectMenu.options[i].value) === Number(id)) {
            selectMenu.remove(i);
            break;
        }
    }
}
