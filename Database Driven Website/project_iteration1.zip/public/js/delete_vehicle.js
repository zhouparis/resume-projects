function deleteVehicle(VIN) {
    let link = '/delete-vehicle-ajax/';
    let data = {
        VIN: VIN
    };

    $.ajax({
        url: link,
        type: 'DELETE',
        data: JSON.stringify(data),
        contentType: "application/json; charset=utf-8",
        success: function(result) {
            deleteRow(VIN);
        }
    });
}

function deleteRow(VIN) {
    let table = document.getElementById("vehicles-table");
    for (let i = 0, row; row = table.rows[i]; i++) {
        if (table.rows[i].getAttribute("data-value") === VIN) {
            table.deleteRow(i);
            deleteDropDownMenu(VIN);
            break;
        }
    }
}

function deleteDropDownMenu(VIN) {
    let selectMenu = document.getElementById("vehicleSelect");
    for (let i = 0; i < selectMenu.length; i++) {
        if (selectMenu.options[i].value === VIN) {
            selectMenu.options[i].remove();
            break;
        }
    }
}
